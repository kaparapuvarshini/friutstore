import React from 'react'
import CartDetails from './CartDetails'
import './FruitStore.css'

const fruits = [
  { id: 1, name: 'Apple', price: '₹250/kg', img: '/apple.jpg' },
  { id: 2, name: 'Banana', price: '₹50/kg', img: '/banana.jpg' },
  { id: 3, name: 'Mango', price: '₹200/kg', img: '/mango.jpg' },
  { id: 4, name: 'Orange', price: '₹120/kg', img: '/orange.jpg' },
  { id: 5, name: 'Grapes', price: '₹180/kg', img: '/grapes.jpg' },
  { id: 6, name: 'Pineapple', price: '₹45/kg', img: '/pineapple.jpg' },
  { id: 7, name: 'Watermelon', price: '₹40/kg', img: '/watermelon.jpg' },
  { id: 8, name: 'Papaya', price: '₹60/kg', img: '/papaya.jpg' },
]

function FruitStore() {

  const [cart, setCart] = React.useState([])

  const addToCart = (fruit) => {

    const existing = cart.find(item => item.id === fruit.id)

    if (existing) {
      setCart(cart.map(item =>
        item.id === fruit.id
          ? { ...item, quantity: item.quantity + 1 }
          : item
      ))
    } else {
      setCart([...cart, { ...fruit, quantity: 1 }])
    }

  }

  return (

    <div className="container">

      <h1>Fresh Fruits Store</h1>

      <div className="grid">

        {fruits.map(fruit => (

          <div key={fruit.id} className="card">

            <img src={fruit.img} alt={fruit.name} />

            <div className="card-content">

              <p>{fruit.name}</p>
              <p>{fruit.price}</p>

              <button onClick={() => addToCart(fruit)}>
                Add to Cart
              </button>

            </div>

          </div>

        ))}

      </div>

      <CartDetails cart={cart} setCart={setCart} />

    </div>

  )

}

export default FruitStore