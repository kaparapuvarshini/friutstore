import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import FruitStore from './FruitStore.jsx'

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <FruitStore />
  </StrictMode>,
)